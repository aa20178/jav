# jav
programmes en java 

L'organisation est la suivante : (ouvrir le readme pour tout voir)

Normalement, avec un IDE on a : 

(voire test/)
src/
	(packages....)
	terminal.	
		Terminal.java
	tp1.
		 Main.java
	tp2.
		Tp2.java
	.
	.
	.
classes/
	terminal.
		Terminal.class
	tp1.
		 Main.class
	tp2.
		Tp2.class
		
		
Les commandes pour faire tourner tout ça seraient : 

Mais dans notre cas, on va faire ça  : 

		
(voire test/)
src/
	(packages....)
	terminal.	
		Terminal.java
		Terminal.class
	tp1.
		 Main.java
		 Main.class
...
